from tkinter import *
from tkinter.scrolledtext import *
from tkinter.messagebox import *
from mysql.connector import *
import matplotlib.pyplot as plt
import numpy as np
import requests


def f1():
	aw.deiconify()
	mw.withdraw()
def f2():
	mw.deiconify()
	aw.withdraw()
	aw_ent_id.delete(0,END)
	aw_ent_name.delete(0,END)
	aw_ent_salary.delete(0,END)
	aw_ent_id.focus()

def f3():
	vw.deiconify()
	mw.withdraw()
	vw_st_data.delete(1.0,END)
	con = None
	try:
		con = connect(host="localhost", user="root", password="abc456",database="ems_db23")
		cursor = con.cursor()
		sql = "select * from emp"
		cursor.execute(sql)
		data = cursor.fetchall()
		info = ""
		for d in data:
			info += "eid " + str(d[0]) + " ename = " + str(d[1]) +  " esalary = " + str(d[2]) + "\n"
		vw_st_data.insert(INSERT, info)
	except Exception as e:
		con.rollback()
		showerror("Issue" , e)
	finally:
		if con is not None:
			con.close()

def f4():
	mw.deiconify()
	vw.withdraw()
def f5():
	uw.deiconify()
	mw.withdraw()
def f6():
	mw.deiconify()
	uw.withdraw()
	uw_ent_id.delete(0,END)
	uw_ent_name.delete(0,END)
	uw_ent_salary.delete(0,END)
	uw_ent_id.focus()
def f7():
	dw.deiconify()
	mw.withdraw()
def f8():
	mw.deiconify()
	dw.withdraw()

def save():
	con = None
	try:
		con = connect(host="localhost", user="root", password="abc456",database="ems_db23")
		cursor = con.cursor()
		sql = "insert into emp (eid,ename,esalary) values(%s,%s,%s)"
		
		eid = aw_ent_id.get()
		eid = eid.strip()
		if (eid == "") or (eid.strip() == ""):
			raise Exception ("ID cannot be null")
		try:
			id = int(eid)
		except ValueError:
			raise Exception("ID should be integers only")

		if (id < 1):
			raise Exception("rno should be min 1")

		ename = aw_ent_name.get()
		if (ename == "") or (ename.strip() == "") :
			raise Exception("Name Cannot Be Null")
		elif (not ename.isalpha()):
			raise Exception("Alpabets Only")
			aw_ent_name.delete(0,END)
		elif (len(ename) < 2):
			raise Exception("Minimum Lenght Should Be 2")
			aw_ent_name.delete(0,END)

		esalary = aw_ent_salary.get()
		esalary = esalary.strip()
		if (esalary == "") or (esalary.strip() == ""):
			raise Exception ("Salary cannot be null")
		try:
			salary = int(esalary)
		except ValueError:
			raise Exception("Salary should be integers only")

		if (salary < 1):
			raise Exception("Minimum salary should be 1")




		cursor.execute(sql , (eid,ename,esalary))
		con.commit()
		showinfo("Successfull","Record created")
		aw_ent_id.delete(0,END)
		aw_ent_name.delete(0,END)
		aw_ent_salary.delete(0,END)
		aw_ent_id.focus()
	except Exception as e:
		con.rollback()
		showerror("issue",e)
	finally:
		if con is not None:
			con.close()

def update():
	con = None
	try:
		con = connect(host="localhost", user="root", password="abc456", database="ems_db23")
		cursor = con.cursor()
		sql = "UPDATE emp SET ename = %s, esalary = %s WHERE eid = %s"

		eid = uw_ent_id.get()
		try:
			eid = int(eid)
		except ValueError:
			raise Exception("ID should be integers only")

		if eid < 1:
			raise Exception("ID should be greater than or equal to 1")

		ename = uw_ent_name.get().strip()
		if not ename:
			raise Exception("Name cannot be null")
		elif not ename.isalpha():
			raise Exception("Name should contain alphabets only")
		elif len(ename) < 2:
			raise Exception("Minimum length of Name should be 2")

		esalary = uw_ent_salary.get().strip()
		try:
			esalary = int(esalary)
		except ValueError:
			raise Exception("Salary should be integers only")
		if esalary < 1:
			raise Exception("Salary should be greater than or equal to 1")

		select_query = "SELECT * FROM emp WHERE eid = %s"
		cursor.execute(select_query, (eid,))
		existing_record = cursor.fetchone()

		if existing_record:
			if askyesno("Confirmation", "Are you sure you want to update the record?"):
				cursor.execute(sql, (ename, esalary, eid))
				con.commit()
				if cursor.rowcount == 1:
					showinfo("Success", "Record updated")
					uw_ent_id.delete(0,END)
					uw_ent_name.delete(0,END)
					uw_ent_salary.delete(0,END)
					uw_ent_id.focus()
				else:
					raise Exception("Record does not exist")
					uw_ent_id.delete(0,END)
					uw_ent_name.delete(0,END)
					uw_ent_salary.delete(0,END)
					uw_ent_id.focus()
		else:
			raise Exception("Record with ID does not exist")
	except Exception as e:
		con.rollback()
		showerror("Issue", e)
	finally:
		if con is not None:
			con.close()
def delete_info():
	con = None	
	try:
		con = connect(host="localhost", user="root", password="abc456", database="ems_db23")
		cursor = con.cursor()        
		sql = "DELETE FROM emp WHERE eid = %s"
		eid = dw_ent_id.get()
		eid = eid.strip()
		if (eid == "") or (eid.strip() == ""):
			raise Exception ("IT CANT BE NULL!")
		try:
			id = int(eid)
		except ValueError:
			raise Exception("ID should be integers only")

		if (id < 1):
			raise Exception("rno should be min 1")
		select_query = "SELECT * FROM emp WHERE eid = %s"
		cursor.execute(select_query, (eid,))
		existing_record = cursor.fetchone()



		if existing_record:
			if askyesno("Confirmation", "Are you sure you want to delete the record?"):

				delete_query = "DELETE FROM emp WHERE eid = %s"
				cursor.execute(delete_query, (eid,))
				con.commit()
				showinfo("Success", "Record deleted")
				dw_ent_id.delete(0, END)
		else:
			raise Exception("ID doesn't exist")
			dw_ent_id.delete(0,END)

	except Exception as e:
		con.rollback()
		showerror("Issue", str(e))
		dw_ent_id.delete(0,END)
		


	finally:
		if con is not None:
			con.close()	

def top_5_emp():
	con = None
	try:
		con = connect(host="localhost", user="root", password="abc456",database="ems_db23")
		cursor = con.cursor()
		sql = "SELECT * FROM emp ORDER BY esalary DESC LIMIT 5"
		cursor.execute(sql)
		top_employees = cursor.fetchall()
		return top_employees
	except mysql.connector.Error as e:
		print("Error executing SQL query:", e)
		return []
	finally:
		if con is not None:
			con.close()

def bar_chart():
	top_employees = top_5_emp()

	if not top_employees:
		showinfo("Error", "No data found.")
		return

	employee_names = [emp[1] for emp in top_employees]  # Assuming the employee name is in the second column
	employee_salaries = [emp[2] for emp in top_employees]  # Assuming the salary is in the third column (index 2)

	plt.bar(employee_names, employee_salaries)
	plt.xlabel('Employee Names')
	plt.ylabel('Salaries')
	plt.title('Top 5 Highest-Paid Employees')
	plt.xticks(rotation=45)  # Rotate the x-axis labels for better readability
	plt.tight_layout()  # To prevent clipping of labels
	plt.show()

def show_bar_chart():
	bar_chart()


		
def get_location():
	try:
		response = requests.get('https://ipinfo.io')
		data = response.json()

		if 'city' in data:
			return data['city']
		else:
			raise Exception('City data not available.')
	except Exception as e:
		raise Exception(f'Error fetching location: {e}')
def show_location():
	try:
		location = get_location()
		loc_label.config(text="Location: " + location)
	except Exception as e:
		print(e)
		showerror("HOLD ON","THERE IS SOME ISSSE")


def loc_temp():
	try:
		response = requests.get('https://ipinfo.io')
		data = response.json()

		if 'loc' in data:
			return data['loc']
		else:
			raise Exception('Location data not available.')
	except Exception as e:
		raise Exception(f'Error fetching location: {e}')

def get_temperature(latitude,longitude):
	api_key = "45ddd7a66a4d10dd7e09f0ad56e23f97"
	url =f"http://api.openweathermap.org/data/2.5/weather?lat={latitude}&lon={longitude}&units=metric&appid={api_key}"
    
	try:
		response = requests.get(url)
		data = response.json()

		if response.status_code == 200 and 'main' in data and 'temp' in data['main']:

			temperature = data['main']['temp']
			return temperature
		else:
			raise Exception('Temperature data not available.')
	except requests.exceptions.RequestException as e:
		raise Exception(f'Error connecting to the weather API: {e}')
	except Exception as e:
		raise Exception(f'Error fetching temperature: {e}')

def show_temp():
	try:
		location = loc_temp()
		latitude,longitude = location.split(',')
		temperature = get_temperature(latitude,longitude)
		temp_label.config(text=f" Temperature: {temperature}°C")
	except Exception as e:	
		print(e)	
		showerror("no","wrong")






mw = Tk()
mw.title("EMPLOY MANAGEMENT SYSTEM")
mw.geometry("500x600+450+80")
f = ("Arial" , 25 , "bold")
mw.configure(bg="lightyellow")

mw_btn_add = Button(mw , text="ADD" , font=f,command=f1)
mw_btn_view = Button(mw , text="VIEW", font=f,command=f3)
mw_btn_update=Button(mw , text="UPDATE" , font=f,command=f5)
mw_btn_delete=Button(mw , text="DELETE" , font=f,command=f7)
mw_btn_charts=Button(mw , text="CHARTS" , font=f,command=bar_chart)

loc_label = Label(mw,font=f, background ="black",foreground="white")
show_location()

temp_label= Label(mw,font=f, background ="black",foreground="white")
show_temp()


mw_btn_add.pack(pady=10)
mw_btn_view.pack(pady=10)
mw_btn_update.pack(pady=10)
mw_btn_delete.pack(pady=10)
mw_btn_charts.pack(pady=10)
loc_label.pack(pady=10)
temp_label.pack(pady=10)


aw = Toplevel(mw)
aw.title("ADD EMPLOYEE")
aw.geometry("500x600+450+80")
aw.configure(bg="lightblue")

aw_lab_id = Label(aw,text="Enter ID",font=f)
aw_ent_id = Entry(aw,font=f)
aw_lab_name = Label(aw,text="Enter NAME",font=f)
aw_ent_name = Entry(aw,font=f)
aw_lab_salary = Label(aw,text="Enter SALARY",font=f)
aw_ent_salary = Entry(aw,font=f)
aw_lab_id.pack(pady=10)
aw_ent_id.pack(pady=10)
aw_lab_name.pack(pady=10)
aw_ent_name.pack(pady=10)
aw_lab_salary.pack(pady=10)
aw_ent_salary.pack(pady=10)

aw_btn_save = Button(aw,text="SAVE", font=f,command=save)
aw_btn_back = Button(aw,text="BACK", font=f,command=f2)
aw_btn_save.pack(pady=10)
aw_btn_back.pack(pady=10)
aw.withdraw()


vw = Toplevel(mw)
vw.title("VIEW EMPLOYEE")
vw.geometry("500x600+450+80")
vw.configure(bg="lightpink")

vw_st_data = ScrolledText(vw, font=f, width=20,height=10)
vw_btn_back =Button(vw, text="BACK", font=f,command=f4)
vw_st_data.pack(pady=10)
vw_btn_back.pack(pady=10)
vw.withdraw()



uw = Toplevel(mw)
uw.title("UPDATE EMPLOYEE")
uw.geometry("500x600+450+80")
uw.configure(bg="aquamarine2")

uw_lab_id = Label(uw,text="Enter ID",font=f)
uw_ent_id = Entry(uw,font=f)
uw_lab_name = Label(uw,text="Enter NAME",font=f)
uw_ent_name = Entry(uw,font=f)
uw_lab_salary = Label(uw,text="Enter SALARY",font=f)
uw_ent_salary = Entry(uw,font=f)
uw_lab_id.pack(pady=10)
uw_ent_id.pack(pady=10)
uw_lab_name.pack(pady=10)
uw_ent_name.pack(pady=10)
uw_lab_salary.pack(pady=10)
uw_ent_salary.pack(pady=10)

uw_btn_save = Button(uw,text="SAVE", font=f,command = update)
uw_btn_back = Button(uw,text="BACK", font=f,command=f6)
uw_btn_save.pack(pady=10)
uw_btn_back.pack(pady=10)
uw.withdraw()


dw = Toplevel(mw)
dw.title("DELETE EMPLOYEE")
dw.geometry("500x600+450+80")
dw.configure(bg="paleturquoise3")

dw_lab_id = Label(dw,text="Enter ID",font=f)
dw_ent_id = Entry(dw,font=f)
dw_lab_id.pack(pady=10)
dw_ent_id.pack(pady=10)



dw_btn_save = Button(dw,text="Delete", font=f,command=delete_info)
dw_btn_back = Button(dw,text="BACK", font=f,command=f8)
dw_btn_save.pack(pady=10)
dw_btn_back.pack(pady=10)
dw.withdraw()


def on_closing():
	if askyesno("WAIT!!","YOU SURE YOU WANNA EXIST"):
		mw.destroy()
mw.protocol("WM_DELETE_WINDOW",on_closing)


mw.mainloop()