import math
px1=float (input('Enter the probability='))
px2=float (input('Enter the probability='))
px3=float (input('Enter the probability='))
px4=float (input('Enter the probability='))
rs=int (input('Enter the symbol rate='))
print('probabilities are:',px1,'\t',px2,'\t',px3,'\t',px4,'\t')
lx1=round (math.log2(1/px1),3)
lx2=round (math.log2(1/px1),3)
lx3=round (math.log2(1/px1),3)
lx4=round (math.log2(1/px1),3)
print('self information are:',lx1, '\t',lx2, '\t',lx3,'\t',lx4,'\t')
Hx=px1*lx1+px2*lx2+px3*lx3+px4*lx4
print('Entropy:',round(Hx,3))
R=Hx*rs
print('Average information rate is:',round(R,3))
print("Harmeet Kaur\nTE-ECS\n121A7044")