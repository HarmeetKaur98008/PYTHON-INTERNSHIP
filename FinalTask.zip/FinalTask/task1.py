from tkinter import *
from time import strftime
from tkinter.messagebox import *
from PIL import ImageTk,Image
from time import sleep
from datetime import datetime
import pytz


def f1():
	cw.deiconify()
	root.withdraw()

def f2():
	root.deiconify()
	cw.withdraw()

def f3():
        sw.deiconify()
        root.withdraw()
def f4():
        root.deiconify()
        sw.withdraw()

def f5():
        cd.deiconify()
        root.withdraw()
def f6():
        root.deiconify()
        cd.withdraw()
        ent1.delete(0,END)
        ent2.delete(0,END)
        ent3.delete(0,END)
        sec.set('00')
        mins.set('00')
        hrs.set('00')
        ent1.focus()
def f7():
        wc.deiconify()
        root.withdraw()
def f8():
        root.deiconify()
        wc.withdraw()


d = datetime.now()
hr = d.hour
msg = ""
if hr < 12:
        msg = "Good Morning"
elif hr < 16:
        msg = "Good Afternoon"
else:
        msg = "Good Evening"



def run():
    current_time = datetime.now()
    diff = current_time - start_time
    txt_var.set('%d.%02d' %(diff.seconds,diff.microseconds//10000))
    
    if running: #for timelapse
        sw.after(20,run) #to reschedule after 20ms,refresh display
 


 
def start():
    global running
    global start_time   


    if not running:
        running = True
        start_time = datetime.now()
        
        sw.after(10,run)
        
def stop():
    global running
    
    running = False
    
def reset():
    
    global start_time
    start_time = datetime.now()    
    
    if not running:
        txt_var.set('00:00:00')
        
running = False
start_time = None

def count():
	try:
		times = int(hrs.get())*3600+ int(mins.get())*60 + int(sec.get())
		while times > -1:
			minute,second = (times // 60 , times % 60)
        
			hour = 0
			if minute > 60:
				hour , minute = (minute // 60 , minute % 60)
      
			sec.set(second)
			mins.set(minute)
			hrs.set(hour)
   
			cd.update()
		
			sleep(1)
		
	
			if(times == 0):
				sec.set('00')
				mins.set('00')
				hrs.set('00')
				showinfo("TIMES UP", "Your Time IS Up")
			times -= 1
	except ValueError:
		showerror("invalid", "numbers only")
		ent1.delete(0,END)
		ent2.delete(0,END)
		ent3.delete(0,END)
		sec.set('00')
		mins.set('00')
		hrs.set('00')
		ent1.focus()                        
                        

def times():
	home = pytz.timezone('Asia/Kolkata')
	local_time = datetime.now(home)
	current_time = local_time.strftime("%H:%M:%S")
	clock.config(text=current_time)
	name.config(text="India")

	home = pytz.timezone('Australia/Victoria')
	local_time = datetime.now(home)
	current_time = local_time.strftime("%H:%M:%S")
	clock1.config(text=current_time)
	name1.config(text="Australia")
	clock.after(200,times)

	home = pytz.timezone('Africa/Timbuktu')
	local_time = datetime.now(home)
	current_time = local_time.strftime("%H:%M:%S")
	clock2.config(text=current_time)
	name2.config(text="Africa")
	






root = Tk()
root.title("DIGITAL CLOCK")
root.geometry("500x500+500+100")
f = ("Century Gothic",20)

image = Image.open("yash.jpeg")
resize_image = image.resize((600,500))
img = ImageTk.PhotoImage(resize_image)


label1 = Label(root,image=img)
label1.image = img
label1.pack()



lab=Label(root, text="Welcome To The App",foreground="black", font=f)
lab.pack(pady=10)
root_btn_time = Button(root, text="TIME", font=f,bg="black",foreground="white",command=f1)
root_btn_stopwatch = Button(root, text="STOPWATCH",font=f,bg="black",foreground="white",command=f3)
root_btn_countdown = Button(root, text="COUNTDOWN",font=f,bg="black",foreground="white",command=f5)
root_btn_worldclock = Button(root, text="WORLDCLOCK",font=f,bg="black",foreground="white",command=f7)
root_btn_time.place(x=50,y=70)
root_btn_stopwatch.place(x=90,y=140)
root_btn_countdown.place(x=190,y=210)
root_btn_worldclock.place(x=240,y=290)



cw = Toplevel(root)
cw.title("TIME")
cw.geometry("500x500+500+100")

image2 = Image.open("image.jpeg")
resize_image2 = image2.resize((500,500))
img2 = ImageTk.PhotoImage(resize_image2)


label2 = Label(cw,image=img2)
label2.image = img2
label2.pack()

def time():
        string = datetime.now().strftime("%I:%M:%S %p")
        cw_label.config(text=string)
        cw_label.after(1000,time)

cw_label = Label(cw,font=("ds-digital",40), background ="black",foreground="white")
cw_label.place(x=120,y=250)
time()


cw_btn_back = Button(cw,text="Back",font=f,bg="black",foreground="white",command=f2)
cw_btn_back.place(x=200,y=400)
cw.withdraw()


cw_label2 = Label(cw,text=msg,font=("Century Gothic",40),bg="black",foreground="white")
cw_label2.place(x=90,y=100)


sw = Toplevel(root)
sw.title("STOPWATCH")
sw.geometry("500x500+500+100")


back_btn = Button(sw,text="BACK",font=f,bg="black",foreground="white",command=f4)
back_btn.place(x=200,y=400)
btn_start = Button(sw,text="START",font=f,bg="black",foreground="white",command=start)
btn_stop = Button(sw,text="STOP",font=f,bg="black",foreground="white",command=stop)
btn_reset = Button(sw,text="RESET",font=f,bg="black",foreground="white",command=reset)
btn_start.place(x=200,y=70)
btn_stop.place(x=200,y=170)
btn_reset.place(x=200,y=270)


txt_var = StringVar()
txt_var.set('00.00.00')


sw_Label= Label(sw,textvariable=txt_var,font=f,bg="white")
sw_Label.pack(pady=10)
sw.withdraw()





cd = Toplevel(root)
cd.title("COUNTDOWN")
cd.geometry("500x500+500+100")



lbl=Label(cd, text="Timer",font=("calibri", 30 ,"bold"))
lbl.pack(pady=10)
back_btn = Button(cd,text="BACK",font=f,bg="black",foreground="white",command=f6)
back_btn.place(x=300,y=250)


sec = StringVar()
mins= StringVar()
hrs= StringVar()

sec.set('00')
mins.set('00')
hrs.set('00')

ent1 = Entry(cd, textvariable = sec, width = 2, font = ("Century Gothic" , 40))
ent2 = Entry(cd, textvariable = mins, width =2, font = ("Century Gothic" ,40))
ent3 = Entry(cd, textvariable = hrs, width =2, font = ("Century Gothic" ,40))
ent1.place(x=325, y=145)
ent2.place(x=225, y=145)
ent3.place(x=125, y=145)


btn_count = Button(cd, text='START',font=f,bg="black",foreground="white",command=count)
btn_count.place(x=100, y=250)
cd.withdraw()

wc = Toplevel(root)
wc.title("WORLDCLOCK")
wc.geometry("500x500+500+100")

image6 = Image.open("image.jpeg")
resize_image6 = image6.resize((500,500))
img6 = ImageTk.PhotoImage(resize_image2)


label6 = Label(wc,image=img6)
label6.image = img6
label6.pack()



name = Label(wc, font=("times",25,"bold"))
name.place(x=50,y=20)
clock = Label(wc, font=("times",25,"bold"))
clock.place(x=20,y=60)
nota = Label(wc, text="hours minutes seconds", font = "times 10 bold")
nota.place(x=30,y=100)

name1 = Label(wc, font=("times",25,"bold"))
name1.place(x=300,y=45)
clock1 = Label(wc, font=("times",25,"bold"))
clock1.place(x=300,y=85)
nota1 = Label(wc, text="hours minutes seconds", font = "times 10 bold")
nota1.place(x=300,y=120)

name2 = Label(wc, font=("times",25,"bold"))
name2.place(x=80,y=200)
clock2 = Label(wc, font=("times",25,"bold"))
clock2.place(x=90,y=250)
nota2 = Label(wc, text="hours minutes seconds", font = "times 10 bold")
nota2.place(x=100,y=300)


back_btn = Button(wc,text="BACK",font=f,bg="black",foreground="white",command=f8)
back_btn.place(x=200,y=400)


times()

def on_closing():
	if askyesno("close","Close Window"):
		root.destroy()
cw.protocol("WM_DELETE_WINDOW", on_closing)
sw.protocol("WM_DELETE_WINDOW", on_closing)
cd.protocol("WM_DELETE_WINDOW", on_closing)
wc.protocol("WM_DELETE_WINDOW", on_closing)
root.protocol("WM_DELETE_WINDOW", on_closing)

root.mainloop()


