import requests
import tkinter as tk
from tkinter.messagebox import showerror

# Replace 'YOUR_API_KEY' with your actual OpenWeatherMap API key
API_KEY = 'YOUR_API_KEY'

def get_location():
    try:
        response = requests.get('https://ipinfo.io')
        data = response.json()

        if 'loc' in data:
            return data['loc']
        else:
            raise Exception('Location data not available.')
    except Exception as e:
        raise Exception(f'Error fetching location: {e}')

def get_weather_data(city_name):
    try:
        url = f'http://api.openweathermap.org/data/2.5/weather?q={city_name}&appid={API_KEY}&units=metric'
        response = requests.get(url)
        data = response.json()

        if data['cod'] == 200:
            return data
        else:
            raise Exception(data['message'])
    except Exception as e:
        raise Exception(f'Error fetching weather data: {e}')

def show_location_and_weather():
    try:
        location = get_location()
        latitude, longitude = location.split(',')
        label_latitude.config(text=f'Latitude: {latitude}')
        label_longitude.config(text=f'Longitude: {longitude}')

        city_name = entry_city.get()
        weather_data = get_weather_data(city_name)
        temperature = weather_data['main']['temp']
        weather_description = weather_data['weather'][0]['description']

        label_temp.config(text=f'Temperature: {temperature}°C')
        label_desc.config(text=f'Weather: {weather_description.capitalize()}')
    except Exception as e:
        showerror('Error', str(e))

app = tk.Tk()
app.title('Current Location and Weather')
app.geometry('400x300')

frame_location = tk.Frame(app)
frame_location.pack(pady=10)

label_latitude = tk.Label(frame_location, text='Latitude:', font=('Arial', 14))
label_latitude.pack()

label_longitude = tk.Label(frame_location, text='Longitude:', font=('Arial', 14))
label_longitude.pack()

frame_weather = tk.Frame(app)
frame_weather.pack(pady=10)

label_city = tk.Label(frame_weather, text='Enter City:', font=('Arial', 14))
label_city.pack(side=tk.LEFT)

entry_city = tk.Entry(frame_weather, font=('Arial', 14))
entry_city.pack(side=tk.LEFT)

button_get_data = tk.Button(app, text='Get Location and Weather', font=('Arial', 14), command=show_location_and_weather)
button_get_data.pack(pady=20)

label_temp = tk.Label(app, font=('Arial', 18))
label_temp.pack()

label_desc = tk.Label(app, font=('Arial', 14))
label_desc.pack()

app.mainloop()
