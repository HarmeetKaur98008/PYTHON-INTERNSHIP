from tkinter import *
from tkinter.scrolledtext import *
from tkinter.messagebox import *
from mysql.connector import *
import matplotlib.pyplot as plt
import numpy as np
import requests
def f1():
	aw.deiconify()
	mw.withdraw()
def f2():
	mw.deiconify()
	aw.withdraw()
def save():
	con = None
	try:
		con = connect(host="localhost", user="root", password="abc456",database="ems_db23")
		cursor = con.cursor()
		sql = "insert into emp (eid,ename,esalary) values(%s,%s,%s)"
		
		eid = aw_ent_id.get()
		eid = eid.strip()
		if (eid == "") or (eid.strip() == ""):
			raise Exception ("ID cannot be null")
		try:
			id = int(eid)
		except ValueError:
			raise Exception("ID should be integers only")

		if (id < 1):
			raise Exception("rno should be min 1")

		ename = aw_ent_name.get()
		if (ename == "") or (ename.strip() == "") :
			raise Exception("Name Cannot Be Null")
		elif (not ename.isalpha()):
			raise Exception("Alpabets Only")
			aw_ent_name.delete(0,END)
		elif (len(ename) < 2):
			raise Exception("Minimum Lenght Should Be 2")
			aw_ent_name.delete(0,END)

		esalary = aw_ent_salary.get()
		esalary = esalary.strip()
		if (esalary == "") or (esalary.strip() == ""):
			raise Exception ("Salary cannot be null")
		try:
			salary = int(esalary)
		except ValueError:
			raise Exception("Salary should be integers only")

		if (salary < 1):
			raise Exception("Minimum salary should be 1")

		print("values to be inserted:",eid,ename,esalary)



		cursor.execute(sql , (eid,ename,esalary))
		con.commit()
		showinfo("Successfull","Record created")
		aw_ent_id.delete(0,END)
		aw_ent_name.delete(0,END)
		aw_ent_salary.delete(0,END)
		aw_ent_id.focus()
	except Exception as e:
		con.rollback()
		print(e)
		showerror("issue",e)
	finally:
		if con is not None:
			con.close()
mw = Tk()
mw.title("EMPLOY MANAGEMENT SYSTEM")
mw.geometry("500x600+100+100")
f = ("Arial" , 25 , "bold")
mw.configure(bg="lightyellow")

mw_btn_add = Button(mw , text="ADD" , font=f,command=f1)
mw_btn_view = Button(mw , text="VIEW", font=f)
mw_btn_update=Button(mw , text="UPDATE" , font=f)
mw_btn_delete=Button(mw , text="DELETE" , font=f)
mw_btn_charts=Button(mw , text="CHARTS" , font=f)




mw_btn_add.pack(pady=10)
mw_btn_view.pack(pady=10)
mw_btn_update.pack(pady=10)
mw_btn_delete.pack(pady=10)
mw_btn_charts.pack(pady=10)



aw = Toplevel(mw)
aw.title("ADD EMPLOYEE")
aw.geometry("500x600+100+100")
aw.configure(bg="lightblue")

aw_lab_id = Label(aw,text="Enter ID",font=f)
aw_ent_id = Entry(aw,font=f)
aw_lab_name = Label(aw,text="Enter NAME",font=f)
aw_ent_name = Entry(aw,font=f)
aw_lab_salary = Label(aw,text="Enter SALARY",font=f)
aw_ent_salary = Entry(aw,font=f)
aw_lab_id.pack(pady=10)
aw_ent_id.pack(pady=10)
aw_lab_name.pack(pady=10)
aw_ent_name.pack(pady=10)
aw_lab_salary.pack(pady=10)
aw_ent_salary.pack(pady=10)

aw_btn_save = Button(aw,text="SAVE", font=f,command=save)
aw_btn_back = Button(aw,text="BACK", font=f,command=f2)
aw_btn_save.pack(pady=10)
aw_btn_back.pack(pady=10)
aw.withdraw()


mw.mainloop()
