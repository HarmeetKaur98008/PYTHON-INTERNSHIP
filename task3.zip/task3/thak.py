from tkinter import *
from tkinter.messagebox import *
from tkinter.scrolledtext import *
from mysql.connector import *

def f1():
	aw.deiconify()
	mw.withdraw()
def f2():
	mw.deiconify()
	aw.withdraw()

def f5():
	con = None
	try:
		con = connect(host="localhost", user="root", password="abc456",database="fms_db23")
		cursor = con.cursor()
		sql = "insert into tp2 values('%d','%s')"

		srno = aw_ent_rno.get()
		srno = srno.strip()
		if (srno == "") or (srno.strip() == "") :
			raise Exception("rno should not be empty")
		try:
			rno = int(srno)
		except ValueError:
			raise Exception("rno should be integers only")


		if rno < 1:
			raise Exception("rno shuld be min 1")

		name = aw_ent_name.get()
		name = name.strip()
		if (name == "") or (not name.isalpha()):
			raise Exception ("invalid name")

		cursor.execute(sql % (rno,name))
		con.commit()
		showinfo("Success " , "Record saved")
		aw_ent_rno.delete(0,END)
		aw_ent_name.delete(0, END)
	except Exception as e:
		con.rollback()
		showerror("issue" , e)
	finally:
		if con is not None:
			con.close()



mw = Tk()
mw.title("Student management system")
mw.geometry("700x500+100+100")
f =("Calibri" , 30 ,"bold")

mw_btn_add = Button(mw,text="Add",font=f, width=5,command=f1)
mw_btn_view= Button(mw,text="view",font=f,width=5)
mw_btn_add.pack(pady=10)
mw_btn_view.pack(pady=10)


aw = Toplevel(mw)
aw.title("Add student")
aw.geometry("700x500+100+100")

aw_lab_rno = Label(aw,text="enter rno", font=f)
aw_ent_rno = Entry(aw,font=f)
aw_lab_rno.pack(pady=10)
aw_ent_rno.pack(pady=10)

aw_lab_name = Label(aw,text="enter name", font=f)
aw_ent_name = Entry(aw,font=f)
aw_lab_name.pack(pady=10)
aw_ent_name.pack(pady=10)

aw_btn_save = Button(aw,text="Save",font=f,command=f5)
aw_btn_back = Button(aw,text="back",font=f,command=f2)
aw_btn_save.pack(pady=10)
aw_btn_back.pack(pady=10)
aw.withdraw()


vw = Toplevel(mw)
vw.title("view student")
vw.geometry("700x500+100+100")

vw_st_data = ScrolledText(vw,font=f,width=30,height=5)
vw_btn_back = Button(vw,text="back",font=f)
vw_st_data.pack(pady=10)
vw_btn_back.pack(pady=10)
vw.withdraw()

mw.mainloop()
