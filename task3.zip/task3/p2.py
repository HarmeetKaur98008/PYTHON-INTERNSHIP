from tkinter import *
from tkinter.scrolledtext import *

def f1():
	tw.deiconify()
	mw.withdraw()
def f2():
	mw.deiconify()
	tw.withdraw()

mw = Tk()
mw.title("DIGITAL CLOCK")
mw.geometry("700x580+450+80")
f = ("Century Gothic",20)
ft1 = ("Arial",20,"bold")
ft2 = ("italic",18,"bold")

btn_admin = Button(mw, text="ADMIN", font=ft1,bg="black",foreground="white",command=f1)
btn_admin.place(x=560,y=30)

lab = Label(mw,text="Hello There",font=f1)
lab1 = Label(mw,text= "We Appreciate your Feedback",font=ft2)
lab_name =  Label(mw,text="Name",font=f)

lab_email = Label(mw,text="Email",font=f)
lab_feed  = Label(mw,text="Comments",font=f)
st_data = ScrolledText(mw, font=f, width=30,height=7)
lab_rate = Label(mw,text="Ratings",font=f)

btn_save = Button(mw,text="Save",font=f)

ent_name = Entry(mw,font=f)
ent_email = Entry(mw,font=f)

c= IntVar()
c.set(1)
rb_1 = Radiobutton(mw,text="1",font=f,variable=c,value=1)
rb_2 = Radiobutton(mw,text="2",font=f,variable=c,value=2)
rb_3 = Radiobutton(mw,text="3",font=f,variable=c,value=3)
rb_4 = Radiobutton(mw,text="4",font=f,variable=c,value=4)
rb_5 = Radiobutton(mw,text="5",font=f,variable=c,value=5)


btn_save.place(x=300,y=600)

lab.place(x=190,y=20)
lab1.place(x=80,y=50)

lab_name.place(x=10,y=100)
ent_name.place(x=120,y=100)
lab_email.place(x=10,y=170)
ent_email.place(x=120,y=170)
lab_feed.place(x=10,y=240)
st_data.place(x=50,y=290)
lab_rate.place(x=10,y=500)

rb_1.place(x=130,y=500)
rb_2.place(x=210,y=500)
rb_3.place(x=300,y=500)
rb_4.place(x=400,y=500)
rb_5.place(x=500,y=500)





tw = Toplevel(mw)
tw.title("TIME")
tw.geometry("700x580+450+80")

tw_btn_back = Button(tw,text="Back",font=f,bg="black",foreground="white",command=f2)
tw_btn_back.place(x=200,y=400)
tw.withdraw()


mw.mainloop()