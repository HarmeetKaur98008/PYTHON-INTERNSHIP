from tkinter import *
from tkinter.scrolledtext import *
from tkinter.messagebox import *
import re
from mysql.connector import *


def f1():
	ap.deiconify()
	mw.withdraw()
	ent_name.delete(0,END)
	ent_email.delete(0,END)
	ent_feed.delete(0,END)

	
def f2():
	ent_user.delete(0,END)
	ent_pass.delete(0,END)
	mw.deiconify()
	ap.withdraw()

def f3():
	con = None
	try:
		con = connect(host="localhost", user="root", password="abc456",database="fms_db23")
		cursor = con.cursor()
		sql = "select * from admin"
		cursor.execute(sql)
		data = cursor.fetchall()
		for d in data:
			if (d[0] != ent_user.get()):
				raise Exception("Invalid username")
				ent_user.delete(0,END)
			elif(d[1] != ent_pass.get()):
				raise Exception("Invalid password")
				ent_pass.delete(0,END)

			
			if (d[0] == ent_user.get()) & (d[1] == ent_pass.get()):
				ent_user.delete(0,END)
				ent_pass.delete(0,END)
				lp.deiconify()
				ap.withdraw()
				mw.withdraw()
				ent_user.delete(0,END)
				ent_pass.delete(0,END)

			else:
				showerror("wrong" , "invalid username or password ")
				ent_user.delete(0,END)
				ent_pass.delete(0,END)

	except Exception as e:
		showerror("issue",e)
	finally:
		if con is not None:
			con.close()

def save():
	con = None
	try:
		con = connect(host="localhost", user="root", password="abc456",database="fms_db23")
		cursor = con.cursor()
		sql = "insert into student values('%s','%s','%s','%s')"

		name = ent_name.get()
		if (name == "") or (name.strip() == "") :
			raise Exception("Name Cannot Be Null")
		elif (not name.isalpha()):
			raise Exception("Alpabets Only")
			ent_name.delete(0,END)
		elif (len(name) < 2):
			raise Exception("Minimum Lenght Should Be 2")
			ent_name.delete(0,END)

	

		email = ent_email.get()
		if (email == "") or (email.strip() == "") :
			raise Exception("COMPULSORY TO ADD YOUR EMAIL!!. IT CANNOT BE EMPTY")
	
		elif len(email)<=6:
			raise Exception("Minimum length should be 6")
			ent_email.delete(0,END)

		elif not email[0].isalpha():
			raise Exception("First letter has to be an alphabet")
			ent_email.delete(0,END)
		
		elif ("@" in email) and (email.count("@") != 1):
			raise Exception("email should have atmost 1 @")
			ent_email.delete(0,END)
		

		comment = ent_feed.get()
		if (comment == "") or (comment.strip == "") :
			raise Exception("Please comment below")


		choice = ""
		if c.get() == 1:
			choice ="One"
		elif c.get() == 2:
			choice = "Two"
		elif c.get() == 3:
			choice = "Three"
		elif c.get() == 4:
			choice = "Four"
		elif c.get() == 5:
			choice ="Five"
		else:
			raise Exception("Please Rate Us To Improve")

		cursor.execute(sql % (name,email,comment,choice))
		con.commit()
		showinfo("thankyou","created")
		ent_name.delete(0,END)
		ent_email.delete(0,END)
		ent_feed.delete(0,END)
	
	except Exception as e:
		con.rollback()
		showerror("issue" , e)

	finally:
		if con is not None:
			con.close()


		
	

def f4():
	ap.deiconify()
	lp.withdraw()
def f5():	
	vp.deiconify()
	lp.withdraw()
	st_data.delete(1.0,END)
	con = None
	try:
		con = connect(host="localhost", user="root", password="abc456",database="fms_db23")
		cursor = con.cursor()		
		sql = "select * from student"
		cursor.execute(sql)
		data = cursor.fetchall()
		info = ""
		for d in data:
			info += "name = " + str(d[0]) + " email = " + str(d[1]) +  " comment = " + str(d[2]) + " choice = " + str(d[3]) + "\n" + "\n"
		st_data.insert(INSERT, info)
	except Exception as e:
		con.rollback()
		showerror("Issue" , e)
	finally:
		if con is not None:
			con.close()


def f6():
	lp.deiconify()
	vp.withdraw()
def f7():
	dp.deiconify()
	lp.withdraw()
def f8():
	lp.deiconify()
	dp.withdraw()

def delete_info():
	con = None	
	try:
		con = connect(host="localhost", user="root", password="abc456", database="fms_db23")
		cursor = con.cursor()        
		sql = "DELETE FROM student WHERE email = %s"
		email = entry.get()

		select_query = "SELECT * FROM student WHERE email = %s"
		cursor.execute(select_query, (email,))
		existing_record = cursor.fetchone()

		if existing_record:
			if askyesno("Confirmation", "Are you sure you want to delete the record?"):

				delete_query = "DELETE FROM student WHERE email = %s"
				cursor.execute(delete_query, (email,))
				con.commit()
				showinfo("Success", "Record deleted")
				entry.delete(0, END)
		else:
			raise Exception("Email doesn't exist")
			entry.delete(0,END)

	except Exception as e:
		con.rollback()
		showerror("Issue", str(e))
		entry.delete(0,END)


	finally:
		if con is not None:
			con.close()		


	






mw = Tk()
mw.title("FMS")
mw.geometry("700x640+450+80")
mw.configure(bg="mediumslateblue")

f = ("Century Gothic",19,"bold")
ft1 = ("Arial",20,"bold")
ft2 = ("italic",18,"bold")

btn_admin = Button(mw, text="ADMIN", font=ft1,bg="black",foreground="white",command=f1)
btn_admin.place(x=560,y=30)

lab = Label(mw,text="Hello There",font=ft1)
lab1 = Label(mw,text= "We Appreciate your Feedback",font=ft2)

lab_name =  Label(mw,text="Name",font=f)
lab_email = Label(mw,text="Email",font=f)
lab_feed  = Label(mw,text="Comments",font=f)

btn_save = Button(mw,text="Save",font=f,command=save)

ent_name = Entry(mw,font=f)
ent_email = Entry(mw,font=f)
ent_feed = Entry(mw,font=f)

c= IntVar()

lab_choice = Label(mw,text="Rate Us",font=f)
rb_one = Radiobutton(mw,text="One",font=f,variable=c,value=1)
rb_two = Radiobutton(mw,text="Two",font=f,variable=c,value=2)
rb_three = Radiobutton(mw,text="Three",font=f,variable=c,value=3)
rb_four = Radiobutton(mw,text="Four",font=f,variable=c,value=4)
rb_five = Radiobutton(mw,text="Five",font=f,variable=c,value=5)



btn_save.place(x=300,y=554)

lab.place(x=190,y=20)
lab1.place(x=80,y=70)

lab_name.place(x=10,y=120)
ent_name.place(x=120,y=120)
lab_email.place(x=10,y=190)
ent_email.place(x=120,y=190)
lab_feed.place(x=10,y=270)
ent_feed.place(x=150,y=270)
lab_choice.place(x=10,y=350)

rb_one.place(x=130,y=350)
rb_two.place(x=300,y=350)
rb_three.place(x=130,y=400)
rb_four.place(x=300,y=400)
rb_five.place(x=210,y=450)





ap = Toplevel(mw)
ap.title("Admin Login")
ap.geometry("500x500+500+100")
ap.configure(bg="mediumpurple")




lab_user = Label(ap,text="Username",font=ft1)
ent_user = Entry(ap,font=f1)
lab_pass = Label(ap,text="Password",font=ft1)
ent_pass = Entry(ap,font=f1)

ap_btn_login = Button (ap,text="Login",font=f,bg="black",foreground="white",command=f3)
ap_btn_back = Button(ap,text="Back",font=f,bg="black",foreground="white",command=f2)
ap_btn_back.place(x=200,y=400)
ap_btn_login.place(x=200,y=320)
lab_user.place(x=170,y=50)
ent_user.place(x=150,y=100)
lab_pass.place(x=170,y=150)
ent_pass.place(x=150,y=200)

ap.withdraw()

lp = Toplevel(ap)
lp.title("Login Page")
lp.geometry("500x500+500+100")
lp.configure(bg="mediumorchid")



btn_view = Button(lp,text="View",font=f,command=f5)
btn_del = Button(lp,text="Delete",font=f,command=f7)
btn_back = Button(lp,text="Back",font=f,command=f4)

btn_view.pack(pady=40)
btn_del.pack(pady=40)
btn_back.pack(pady=40)

lp.withdraw()


vp = Toplevel(lp)
vp.title("View Page")
vp.geometry("700x640+450+80")
vp.configure(bg="mediumorchid")




st_data = ScrolledText(vp, font=f, width=45,height=18)
btn_back = Button(vp,text="Back",font=f,command=f6)
btn_back.place(x=250,y=580)
st_data.pack(pady=10)

vp.withdraw()


dp = Toplevel(vp)
dp.title("View Page")
dp.geometry("500x500+500+100")
dp.configure(bg="coral")



label = Label(dp,text="Enter Email",font=f)
entry = Entry(dp,font=f)
btn_back = Button(dp,text="Back",font=f,command=f8)
btn_del1 = Button(dp,text="Delete",font=f,command=delete_info)
btn_back.place(x=250,y=400)
label.pack(pady=30)
entry.pack(pady=30)
btn_del1.pack(pady=30)

dp.withdraw()



def on_closing():
	if askyesno("WAIT!!","YOU SURE YOU WANNA EXIST"):
		mw.destroy()
mw.protocol("WM_DELETE_WINDOW",on_closing)










mw.mainloop()