




con = None
	try:
		con = connect("task3_db")
		cursor = con.cursor()
		sql = "insert into tp1 values('%s','%s')"
		
		fname = ent_name.get()
		if (fname == "") or (fname.strip() == "") or (not fname.isalpha()):
			showerror("wrong" , "invalid name")
			ent_name.delete(0 , END)
			ent_name.focus()
			return

		femail = ent_email.get()
		pat = "^[a-zA-Z0-9-_]+@[a-zA-Z0-9]+\.[a-z]{1,3}$"
		if re.match(pat,femail):
			return True
		else:
			showerror("no","invalid email")



		else (email == ""):
			showerror("no","email cant be null")
			con.rollback()

	

		cursor.execute(sql % (fname,femail,))
		con.commit()
		showinfo("Success " , "Record saved")

	except Exception as e:
		con.rollback()
		showerror("issue" , e)
	finally:
		if con is not None:
			con.close()




















fcomment = st_data.get()
		if (fcomment == "") or (fcomment.strip() == ""):
			showerror("wrong" , "enter something in the comment section")
			st_data.delete(0, END)
			st_data.focus()
			return
	
		fchoice = c.get()
		fchoice = ""
		if c.get() == 1:
			choice = "1"
		elif c.get() == 2:
			choice = "2"
		elif c.get() == 3:
			choice = "3"
		elif c.get() == 4:
			choice = "4"
		else:
			choice = "5"