# using mysql as database for task3 internship

from tkinter import *
from tkinter.scrolledtext import *
from tkinter.messagebox import *
from sqlite3 import *
from mysql.connector import *
import re

def save():
	con = None
	try:
		con = connect(host="localhost", user="root", password="abc456",database="fms_db23")
		cursor = con.cursor()
		sql = "insert into harmeet values('%s','%s','%s','%s')"

		name = ent_name.get()
		if (name == "") or (name.strip() == "") :
			raise Exception("Name Cannot Be Null")
		elif (not name.isalpha()):
			raise Exception("Alpabets Only")
		elif (len(name) < 2):
			raise Exception("Minimum Lenght Should Be 2")
	

		email = ent_email.get()
		if (email == "") or (email.strip() == "") :
			raise Exception("COMPULSORY TO ADD YOUR EMAIL!!. IT CANNOT BE EMPTY")
	
		elif len(email)<=6:
			raise Exception("Minimum length should be 6")

		elif not email[0].isalpha():
			raise Exception("First letter has to be an alphabet")
		
		elif ("@" in email) and (email.count("@") != 1):
			raise Exception("email should have atmost 1 @")

		elif (email[-4] !=".") ^ (email[-3] !="."):
			raise Exception("invalid email")
		
		

		

		comment = ent_feed.get()
		if (comment == "") or (comment.strip == "") :
			raise Exception("Please comment below")
		elif (not comment.isalpha()):
			raise Exception ("Sorry we cant understand what you are trying to say.Please be more clear to help us understand you")

		choice = ""
		if c.get() == 1:
			choice ="One"
		elif c.get() == 2:
			choice = "Two"
		elif c.get() == 3:
			choice = "Three"
		elif c.get() == 4:
			choice = "Four"
		elif c.get() == 5:
			choice ="Five"
		else:
			raise Exception("Please Rate Us To Improve")

		cursor.execute(sql % (name,email,comment,choice))
		con.commit()
		showinfo("thankyou","created")
	
	except Exception as e:
		con.rollback()
		showerror("issue" , e)
	finally:
		if con is not None:
			con.close()

		
	




mw = Tk()
mw.title("FMS")
mw.geometry("700x640+450+80")
f = ("Century Gothic",19,"bold")
ft1 = ("Arial",20,"bold")
ft2 = ("italic",18,"bold")

btn_admin = Button(mw, text="ADMIN", font=ft1,bg="black",foreground="white")
btn_admin.place(x=560,y=30)

lab = Label(mw,text="Hello There",font=ft1)
lab1 = Label(mw,text= "We Appreciate your Feedback",font=ft2)

lab_name =  Label(mw,text="Name",font=f)
lab_email = Label(mw,text="Email",font=f)
lab_feed  = Label(mw,text="Comments",font=f)

btn_save = Button(mw,text="Save",font=f,command=save)

ent_name = Entry(mw,font=f)
ent_email = Entry(mw,font=f)
ent_feed = Entry(mw,font=f)

c= IntVar()

lab_choice = Label(mw,text="Rate Us",font=f)
rb_one = Radiobutton(mw,text="One",font=f,variable=c,value=1)
rb_two = Radiobutton(mw,text="Two",font=f,variable=c,value=2)
rb_three = Radiobutton(mw,text="Three",font=f,variable=c,value=3)
rb_four = Radiobutton(mw,text="Four",font=f,variable=c,value=4)
rb_five = Radiobutton(mw,text="Five",font=f,variable=c,value=5)



btn_save.place(x=300,y=554)

lab.place(x=190,y=20)
lab1.place(x=80,y=50)

lab_name.place(x=10,y=100)
ent_name.place(x=120,y=100)
lab_email.place(x=10,y=170)
ent_email.place(x=120,y=170)
lab_feed.place(x=10,y=240)
ent_feed.place(x=150,y=240)
lab_choice.place(x=10,y=300)

rb_one.place(x=130,y=300)
rb_two.place(x=300,y=300)
rb_three.place(x=130,y=350)
rb_four.place(x=300,y=350)
rb_five.place(x=220,y=400)


mw.mainloop()