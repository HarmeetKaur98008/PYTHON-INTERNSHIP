from tkinter import *
from tkinter.scrolledtext import *

def f1():
	tw.deiconify()
	mw.withdraw()
def f2():
	mw.deiconify()
	tw.withdraw()

mw = Tk()
mw.title("DIGITAL CLOCK")
mw.geometry("500x500+500+100")
f = ("Century Gothic",20)

mw_btn_time = Button(mw, text="TIME", font=f,bg="black",foreground="white",command=f1)
mw_btn_time.place(x=240,y=100)


tw = Toplevel(mw)
tw.title("TIME")
tw.geometry("500x500+500+100")

tw_btn_back = Button(tw,text="Back",font=f,bg="black",foreground="white",command=f2)
tw_btn_back.place(x=200,y=400)
tw.withdraw()

mw.mainloop()