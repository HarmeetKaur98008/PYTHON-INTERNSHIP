from tkinter import *
import math

def clear():
    global equation
    text = equation[:-1]
    equation = text
    text_input.set(text)

def visible(char):
    global equation
    equation += str(char)
    text_input.set(equation)

def clear_all():
    global equation
    equation = ""
    text_input.set("")

def sine():
    global equation
    result = str(math.sin(math.radians(int(equation))))
    equation = result
    text_input.set(result)

def cosine():
    global equation
    result = str(math.cos(math.radians(int(equation))))
    equation = result
    text_input.set(result)

def tangent():
    global equation
    result = str(math.tan(math.radians(int(equation))))
    equation = result
    text_input.set(result)

def cotangent():
    global equation
    result = str(1/math.tan(math.radians(int(equation))))
    equation = result
    text_input.set(result)


def percent():
    global equation
    temp = str(eval(equation+'/100'))
    equation = temp
    text_input.set(temp)

def equals():
	global equation
	try:
		temp_op = str(eval(equation))
		text_input.set(temp_op)
		equation = temp_op
	except ZeroDivisionError:
		text_input.set("cannot divide by 0")
	except SyntaxError:
		text_input.set("invalid syntax")

sin, cos, tan = math.sin, math.cos, math.tan
ln =  math.log
p = math.pi

root = Tk()
root.configure(bg="lightyellow", bd=10)
root.title("Calculator")
root.iconbitmap("calci.ico")


equation = ""
text_input = StringVar()
f = ('sans-serif', 20, 'bold')

button_style = {'bd':5, 'fg':'#BBB', 'bg':'#3C3636', 'font':('sans-serif', 20, 'bold')}
button_style2 = {'bd':5, 'fg':'black', 'bg':'#BBB', 'font':('sans-serif', 20, 'bold')}



ent = Entry(root, font=f, textvariable=text_input, bd=5,bg='#BBB', justify='right')
ent.grid(columnspan=5, padx = 10, pady = 15)

sin = Button(root, button_style, text='sin',command=sine)
sin.grid(row=1, column=0, sticky="nsew")
cos = Button(root, button_style, text='cos',command=cosine)
cos.grid(row=1, column=1, sticky="nsew")
tan = Button(root, button_style, text='tan',command=tangent)
tan.grid(row=1, column=2, sticky="nsew")
cot = Button(root, button_style, text='cot',command=cotangent)
cot.grid(row=1, column=3, sticky="nsew")
pi_num = Button(root, button_style, text='π',command=lambda:visible(str(math.pi)))
pi_num.grid(row=1, column=4, sticky="nsew")


left_par = Button(root, button_style, text='(',command=lambda:visible('('))
left_par.grid(row=2, column=0, sticky="nsew")
right_par = Button(root, button_style, text=')',command=lambda:visible(')'))
right_par.grid(row=2, column=1, sticky="nsew")
log_base = Button(root, button_style, text='ln',command=lambda:visible('ln('))
log_base.grid(row=2, column=2, sticky="nsew")
x_square = Button(root, button_style, text='x\u00B2',command=lambda:visible('**2'))
x_square.grid(row=2, column=3, sticky="nsew")
percentage = Button(root, button_style, text='%',command=percent)
percentage.grid(row=2, column=4, sticky="nsew")


btn7 = Button(root, button_style2, text='7',command=lambda:visible('7'))
btn7.grid(row=3, column=0, sticky="nsew")
btn8 = Button(root, button_style2, text='8',command=lambda:visible('8'))
btn8.grid(row=3, column=1, sticky="nsew")
btn9 = Button(root, button_style2, text='9',command=lambda:visible('9'))
btn9.grid(row=3, column=2, sticky="nsew")
delete_1 = Button(root, bd=5, fg='black', font=f, text='DEL',command=clear)
delete_1.grid(row=3, column=3, sticky="nsew")
delete_all = Button(root, bd=5, fg='black', font=f,text='AC', command=clear_all)
delete_all.grid(row=3, column=4, sticky="nsew")

btn4 = Button(root, button_style2, text='4',command=lambda:visible('4'))
btn4.grid(row=4, column=0, sticky="nsew")
btn5 = Button(root, button_style2, text='5',command=lambda:visible('5'))
btn5.grid(row=4, column=1, sticky="nsew")
btn6 = Button(root, button_style2, text='6',command=lambda:visible('6'))
btn6.grid(row=4, column=2, sticky="nsew")
mul = Button(root, button_style2, text='*',command=lambda:visible('*'))
mul.grid(row=4, column=3, sticky="nsew")
div = Button(root, button_style2, text='/',command=lambda:visible('/'))
div.grid(row=4, column=4, sticky="nsew")

btn1 = Button(root, button_style2, text='1',command=lambda:visible('1'))
btn1.grid(row=5, column=0, sticky="nsew")
btn2 = Button(root, button_style2, text='2',command=lambda:visible('2'))
btn2.grid(row=5, column=1, sticky="nsew")
btn3 = Button(root, button_style2, text='3',command=lambda:visible('3'))
btn3.grid(row=5, column=2, sticky="nsew")
add = Button(root, button_style2, text='+',command=lambda:visible('+'))
add.grid(row=5, column=3, sticky="nsew")
sub = Button(root, button_style2, text='-',command=lambda:visible('-'))
sub.grid(row=5, column=4, sticky="nsew")

btn0 = Button(root, button_style2, text='0',command=lambda:visible('0'))
btn0.grid(row=6, column=0, sticky="nsew")
decimal = Button(root, button_style2, text='.',command=lambda:visible('.'))
decimal.grid(row=6, column=1, sticky="nsew")
btn00 = Button(root, button_style2, text='00',command=lambda:visible('00'))
btn00.grid(row=6, column=2, sticky="nsew")
equal = Button(root, button_style2, text='=',command=equals)
equal.grid(row=6, columnspan=2, column=3, sticky="nsew")

   

root.mainloop()