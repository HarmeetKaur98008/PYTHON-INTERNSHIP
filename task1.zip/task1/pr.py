a=int(input("enter minutes "))

m = a * 60

b = int(input("enter hours "))

h = b * 3600

c = int(input("enter sec "))

s = c

res = m+h+c

print(res)