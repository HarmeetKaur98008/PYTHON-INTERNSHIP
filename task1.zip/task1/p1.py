from tkinter import *
from tkinter.messagebox import *
from time import sleep
from datetime import datetime
from PIL import ImageTk,Image
import pytz

def f1():
	tw.deiconify()
	mw.withdraw()
def f2():
	mw.deiconify()
	tw.withdraw()
def f3():
	wc.deiconify()
	mw.withdraw()
def f4():
	mw.deiconify()
	wc.withdraw()
def f5():
	sw.deiconify()
	mw.withdraw()
def f6():
	mw.deiconify()
	sw.withdraw()
def f7():
	iw.deiconify()
	wc.withdraw()
def f8():
	wc.deiconify()
	iw.withdraw()
def f9():
	us.deiconify()
	wc.withdraw()
def f10():
	wc.deiconify()
	us.withdraw()
def f11():
	gb.deiconify()
	wc.withdraw()
def f12():
	wc.deiconify()
	gb.withdraw()
def f13():
	jp.deiconify()
	wc.withdraw()
def f14():
	wc.deiconify()
	jp.withdraw()
def f15():
	cd.deiconify()
	mw.withdraw()
def f16():
	mw.deiconify()
	cd.withdraw()
	ent1.delete(0,END)
	ent2.delete(0,END)
	ent3.delete(0,END)
	sec.set('00')
	mins.set('00')
	hrs.set('00')
	ent1.focus()


	

def times():
	home=pytz.timezone("Asia/kolkata")
	local_time=datetime.now(home)
	current_time=local_time.strftime("%a %I:%M:%S")
	clock.config(text=current_time)
	name.config(text="India")
	clock.after(200,times)
def usa():
	home2 = pytz.timezone("America/New_York")
	local_time2=datetime.now(home2)
	current_time2=local_time2.strftime("%a %I:%M:%S")
	clock2.config(text=current_time2)
	name2.config(text="New York")
	clock2.after(200,times)
def lon():
	home3 = pytz.timezone("europe/london")
	local_time3=datetime.now(home3)
	current_time3=local_time3.strftime("%a %I:%M:%S")
	clock3.config(text=current_time3)
	name3.config(text="London")
	clock3.after(200,times)
def tok():
	home4 = pytz.timezone("Asia/tokyo")
	local_time4=datetime.now(home4)
	current_time4=local_time4.strftime("%a %I:%M:%S")
	clock4.config(text=current_time4)
	name4.config(text="Tokyo")
	clock4.after(200,times)

d = datetime.now()
hr = d.hour
msg = ""
if hr < 12:
	msg = "Good Morning"
elif hr < 16:
	msg = "Good Afternoon"
else:
	msg = "Good Evening"


def run():
    current_time = datetime.now()
    diff = current_time - start_time
    txt_var.set('%d.%02d' %(diff.seconds,diff.microseconds//10000))
    
    if running: #for timelapse
        sw.after(20,run) #to reschedule after 20ms,refresh display
 

 
def start():
    global running
    global start_time   

    if not running:
        running = True
        start_time = datetime.now()
        
        sw.after(10,run)
        
def stop():
    global running
    
    running = False
    
def reset():
    
    global start_time
    start_time = datetime.now()    
    
    if not running:
        txt_var.set('0:00')
        
running = False
start_time = None


def count():
	try:
		times = int(hrs.get())*3600+ int(mins.get())*60 + int(sec.get())
		while times > -1:
			minute,second = (times // 60 , times % 60)
        
			hour = 0
			if minute > 60:
				hour , minute = (minute // 60 , minute % 60)
      
			sec.set(second)
			mins.set(minute)
			hrs.set(hour)
   
			cd.update()
		
			sleep(1)
		
	
			if(times == 0):
				sec.set('00')
				mins.set('00')
				hrs.set('00')
				showinfo("TIMES UP", "Your Time IS Up")
			times -= 1
	except ValueError:
		showerror("invalid", "numbers only")
		ent1.delete(0,END)
		ent2.delete(0,END)
		ent3.delete(0,END)
		sec.set('00')
		mins.set('00')
		hrs.set('00')
		ent1.focus()

			

mw = Tk()
mw.title("DIGITAL CLOCK")
mw.geometry("500x500+500+100")
f = ("Century Gothic",20)
mw.iconbitmap("harmeet.ico")  basss itna hi karna haiiii!!!

image = Image.open("time.png")
resize_image = image.resize((600,500))
img = ImageTk.PhotoImage(resize_image)

label1 = Label(mw,image=img)
label1.image = img
label1.pack()


mw_btn_time = Button(mw, text="TIME", font=f,bg="black",foreground="white",command=f1)
mw_btn_worldclock = Button(mw, text="WORLDCLOCK",font=f,bg="black",foreground="white",command=f3)
mw_btn_stopwatch = Button(mw, text="STOPWATCH",font=f,bg="black",foreground="white",command=f5)
mw_btn_countdown = Button(mw, text="COUNTDOWN",font=f,bg="black",foreground="white",command=f15)
mw_btn_time.place(x=240,y=100)
mw_btn_worldclock.place(x=240,y=200)
mw_btn_stopwatch.place(x=240,y=300)
mw_btn_countdown.place(x=240,y=400)


tw = Toplevel(mw)
tw.title("TIME")
tw.geometry("500x500+500+100")
tw.iconbitmap("harmeet.ico")

image2 = Image.open("time2.png")
resize_image2 = image2.resize((500,500))
img2 = ImageTk.PhotoImage(resize_image2)

label2 = Label(tw,image=img2)
label2.image = img2
label2.pack()

def time():
	string = datetime.now().strftime("%I:%M:%S %p")
	tw_label.config(text=string)
	tw_label.after(1000,time)


tw_label = Label(tw,font=("ds-digital",40), background ="black",foreground="white")
tw_label.place(x=120,y=250)
time()

tw_btn_back = Button(tw,text="Back",font=f,bg="black",foreground="white",command=f2)
tw_btn_back.place(x=200,y=400)
tw.withdraw()

tw_label2 = Label(tw,text=msg,font=("Century Gothic",40),bg="black",foreground="white")
tw_label2.place(x=90,y=100)

wc = Toplevel(mw)
wc.title("countdown")
wc.geometry("500x500+500+100")
wc.iconbitmap("harmeet.ico")

image3 = Image.open("third.png")
resize_image3 = image3.resize((500,500))
img3 = ImageTk.PhotoImage(resize_image3)

label3 = Label(wc,image=img3)
label3.image = img3
label3.pack()


back_btn = Button(wc,text="BACK",font=f,bg="black",foreground="white",command=f4)
back_btn.place(x=200,y=400)

in_btn = Button(wc,text="INDIA",font=f,bg="black",foreground="white",command=f7)
jp_btn = Button(wc,text="TOKYO",font=f,bg="black",foreground="white",command=f13)
gb_btn = Button(wc,text="LONDON",font=f,bg="black",foreground="white",command=f11)
us_btn = Button(wc,text="NEW YORK",font=f,bg="black",foreground="white",command=f9)
in_btn.place(x=90,y=100)
jp_btn.place(x=300,y=250)
gb_btn.place(x=90,y=250)
us_btn.place(x=300,y=100)



iw = Toplevel(wc)
iw.title("INDIA")
iw.geometry("250x200+600+250")
iw_btn = Button(iw,text="BACK",font=("Arial",15,"bold"),command=f8)
iw_btn.place(x=90,y=130)
iw.iconbitmap("india.ico")



# 1st
name = Label(iw,font=("Helvetica",20,"bold"))
name.place(x=70,y=20)

logo=PhotoImage(file="in.png")
image_Label=Label(iw,image=logo)
image_Label.place(x=20,y=20)

clock=Label(iw,font=("Helvetica",20,"bold"))
clock.place(x=27,y=75)
times()
iw.withdraw()

us = Toplevel(wc)
us.title("NEW YORK")
us.geometry("250x200+600+250")
us_btn = Button(us,text="BACK",font=("Arial",15,"bold"),command=f10)
us_btn.place(x=90,y=130)
us.iconbitmap("usa.ico")

# 2nd
name2 = Label(us,font=("Helvetica",20,"bold"))
name2.place(x=70,y=20)

logo2=PhotoImage(file="us.png")
image_Label2=Label(us,image=logo2)
image_Label2.place(x=20,y=20)

clock2=Label(us,font=("Helvetica",20,"bold"))
clock2.place(x=27,y=75)
usa()
us.withdraw()

gb = Toplevel(wc)
gb.title("LONDON")
gb.geometry("250x200+600+250")
gb_btn = Button(gb,text="BACK",font=("Arial",15,"bold"),command=f12)
gb_btn.place(x=90,y=130)
gb.iconbitmap("europe.ico")

# 3rd
name3 = Label(gb,font=("Helvetica",20,"bold"))
name3.place(x=70,y=20)

logo3=PhotoImage(file="gb.png")
image_Label3=Label(gb,image=logo3)
image_Label3.place(x=20,y=20)

clock3=Label(gb,font=("Helvetica",20))
clock3.place(x=27,y=75)
lon()
gb.withdraw()

jp = Toplevel(wc)
jp.title("JAPAN")
jp.geometry("250x200+600+250")
jp_btn = Button(jp,text="BACK",font=("Arial",15,"bold"),command=f14)
jp_btn.place(x=90,y=130)
jp.iconbitmap("japan.ico")

# 4th
name4 = Label(jp,font=("Helvetica",20,"bold"))
name4.place(x=70,y=20)

logo4=PhotoImage(file="jp.png")
image_Label4=Label(jp,image=logo4)
image_Label4.place(x=20,y=20)

clock4=Label(jp,font=("Helvetica",20))
clock4.place(x=27,y=75)
tok()
jp.withdraw()

wc.withdraw()



sw = Toplevel(mw)
sw.title("STOPWATCH")
sw.geometry("500x500+500+100")
sw.iconbitmap("harmeet.ico")

img5=Image.open('perfect2.png')
img6=ImageTk.PhotoImage(img5)
Label(sw,image=img6).place(x=0,y=0)

back_btn = Button(sw,text="BACK",font=f,bg="black",foreground="white",command=f6)
back_btn.place(x=200,y=400)
btn_start = Button(sw,text="START",font=f,bg="black",foreground="white",command=start)
btn_stop = Button(sw,text="STOP",font=f,bg="black",foreground="white",command=stop)
btn_reset = Button(sw,text="RESET",font=f,bg="black",foreground="white",command=reset)
btn_start.place(x=200,y=70)
btn_stop.place(x=200,y=170)
btn_reset.place(x=200,y=270)

txt_var = StringVar()
txt_var.set('0.00')

sw_Label= Label(sw,textvariable=txt_var,font=f)
sw_Label.pack(pady=10)
sw.withdraw()


cd = Toplevel(mw)
cd.title("COUNTDOWN")
cd.geometry("500x500+500+100")
cd.iconbitmap("harmeet.ico")

img7=Image.open('perfect2.png')
img8=ImageTk.PhotoImage(img7)
Label(cd,image=img8).place(x=0,y=0)

back_btn = Button(cd,text="BACK",font=f,bg="black",foreground="white",command=f16)
back_btn.place(x=200,y=400)

sec = StringVar()
mins= StringVar()
hrs= StringVar()

sec.set('00')
mins.set('00')
hrs.set('00')



ent1 = Entry(cd, textvariable = sec, width = 2, font = ("Century Gothic" , 40))
ent2 = Entry(cd, textvariable = mins, width =2, font = ("Century Gothic" ,40))
ent3 = Entry(cd, textvariable = hrs, width =2, font = ("Century Gothic" ,40))
ent1.place(x=325, y=155)
ent2.place(x=225, y=155)
ent3.place(x=125, y=155)

btn_count = Button(cd, text='START',font=f,bg="black",foreground="white",command=count)
btn_count.place(x=200, y=300)
cd.withdraw()

mw.mainloop()